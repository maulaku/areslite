Project JvInterpreterEndUser.dpr require Quick Report 2,
so it can be compiled in D3, D4, but not in D2 or CB1.
